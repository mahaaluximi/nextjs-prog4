import { NextResponse } from "next/server"

export function middleware(request) {
    console.log('request',request)
    return NextResponse.next()
}
// this matcher property is to configure the kind of request that you want to apply the middleware
export const config = {
   matcher: '/:path*'
    //matcher: '/news'
}