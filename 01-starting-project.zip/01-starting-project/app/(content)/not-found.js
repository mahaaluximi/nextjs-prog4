export default function NotFound() {
    return (
        <div id="error">
            <h1>Not Found</h1>
            <p>Could not find requested resource</p>
        </div>
    );
}