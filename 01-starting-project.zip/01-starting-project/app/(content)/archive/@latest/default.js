import NewsList from "@/components/news-list";
import { getLatestNews } from "@/lib/news";
import Head from "next/head";

//default.js file is required in case of parallel routes as if any of the nested routes are not defined then it will throw error as not found as the route is missing. The default.js file handle such errors and the page gets loaded without issue
//this is not required if the nested routes are defined
//always parallel routes are rendered together and so the error is returned
//Note: If the page.ts as well as default.js returns the same content then that page.ts file can be removed
export default function LatestNewsPage() {
    const news = getLatestNews();
    console.log('news',news);
    return (
        <>
            <h2>Latest News</h2>
            <NewsList news={news} />
            
        </>
    );
}