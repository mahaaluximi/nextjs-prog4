import NewsList from "@/components/news-list";
import { getNewsForYear, getAvailableNewsYears, getAvailableNewsMonths, getNewsForYearAndMonth} from "@/lib/news";
import Link from "next/link";
import { Suspense } from "react";

//[[...year]] is a dynamic segment which covers all the nested routes/any segments we say example: archive/2024 , archive/2024/01/01

function FilteredNews({year, month}) {
    let news;

    if(year && !month) {
        news = getNewsForYear(year);
    }
    else if(year && month) {
        news = getNewsForYearAndMonth(year, month);
    }
     //news = getNewsForYear(selectedYear);
    let newsContent = <p>No news found</p>

    if(news?.length > 0) {
        newsContent = <NewsList news={news} />;
    }
    console.log('new',news);
    return newsContent;
}

export default function ArchiveYearPage({ params }) {
    //Now the param sludge/filter value will be an array
    const filter = params.filter;
    console.log('filter',filter, 'params',params);

    const availableYears = getAvailableNewsYears();
    let links = getAvailableNewsYears();

    const selectedYear = filter?.[0];
    const selectedMonth = filter?.[1];

    let news;

    if (selectedYear && !selectedMonth) {
       
        links = getAvailableNewsMonths(selectedYear);
        
    }
    if (selectedYear && selectedMonth) {
        news = getNewsForYearAndMonth(selectedYear, selectedMonth);
        links = [];
        
    }

   
//     const news = getNewsForYear(params.filter[0]);
//     return (
//         <NewsList news={news} />
//     );
    const href = `/archive`;
    console.log('href',href);

    if(selectedYear && !getAvailableNewsYears().includes(+selectedYear) || selectedMonth && !getAvailableNewsMonths(selectedYear).includes(+selectedMonth)) {
       throw new Error('Invalid year or month');
    }
   
    return  (
        <>
            <header id="archive-header">
                <nav>
                    <ul>
                        {links.map((year) => {
                            const href = selectedYear? `/archive/${selectedYear}/${year}`: `/archive/${year}`;
                            return (<li key={year}>
                                <Link href={href}>{year}</Link>
                            </li>)
                    })}
                    </ul>
                </nav>
            </header>
            <Suspense fallback={<p>Loading News...</p>}>
                <FilteredNews year={selectedYear} month={selectedMonth} />
            </Suspense>
        </>    
    );
 }