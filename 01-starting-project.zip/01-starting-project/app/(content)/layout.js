'use client';
import { QueryClient, QueryClientProvider } from 'react-query';
import '../globals.css';
import MainHeader from '@/components/main-header';

// export const metadata = {
//   title: 'Next.js Page Routing & Rendering',
//   description: 'Learn how to route to different pages.',
// }

export default function RootLayout({ children }) {
 const queryClient = new QueryClient(); 
 return (
    <html lang="en">
      <body>
        <div id="page">
          <MainHeader />
          <QueryClientProvider client={queryClient}>
            {children}
          </QueryClientProvider>
        </div>
      </body>
    </html>
  )
}
