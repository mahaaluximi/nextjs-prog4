const Loader = () => {
    return <h1>Loading...</h1>;
}

export default Loader;