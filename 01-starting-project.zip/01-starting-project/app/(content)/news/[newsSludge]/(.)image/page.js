'use client';
import { DUMMY_NEWS } from "@/dummy-news";
import { notFound, useRouter } from "next/navigation";
// Intercepting routes are used if we need to display different content when we navigate via the internal links or external links or by reloading the page
//syntax: ()xx -> xx- the path or the route to be intercepted
/* (.) -> If the intercepting rpute is same as the current route ie both on the same page 
 (..) -> one level up
 (..)(..) -> two levels up
 (..)(..)(..) -> three levels up and so on
 (...) -> to match segments from the root app directory
 Note: This page is invoked when invoked internally, ie different content is displayed depending on how we navigate to this page
 The parallel route path will be ignored
*/
    export default function InterceptingImagePage({params}) {
    const slug = params.newsSludge
    const news = DUMMY_NEWS.find((item) => item.slug === slug);
    const router = useRouter();
    if(!news) {
        notFound();
    }
    return(
        <>
        <div className="modal-backdrop" onClick={router.back}>
            <dialog className="modal" open>
            <div className="fullscreen-image"><img src={`/images/news/${news.image}`} alt={news.title} />
            </div>
            </dialog>
        </div>
        </>);
}