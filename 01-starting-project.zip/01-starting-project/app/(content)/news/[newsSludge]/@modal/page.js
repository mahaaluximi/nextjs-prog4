export default function ModalDefaultPage() {
    return <h1>Modal Default Page</h1>;
}
