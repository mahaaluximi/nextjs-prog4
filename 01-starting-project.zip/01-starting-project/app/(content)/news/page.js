//'use client';
import "@/app/globals.css";
//import { DUMMY_NEWS } from "@/dummy-news";
import NewsList from "@/components/news-list";
// import { useEffect, useState } from "react";
// import { useQuery } from "react-query";
import axios from "axios";

export default async function NewsPage() {
    //Commenting out to use react-query as extracting the data at the server side
    // const [news, setNews] = useState([]);
    
    // const {data, isLoading, error} = useQuery('news',async ()=>{ 
    //     const response = await axios.get('http://localhost:8080/news');
    //     return response.data;
    // });
        
    // useEffect(() => {
    //     if(data) {
    //         setNews(data);
    //     }
    // }, [data]);

    // if(isLoading) {
    //     return <p>Loading...</p>;
    // }

    // if(error) {
    //     return <p>{error.message}</p>;
    // }
    // console.log('news:',news);
    const response = await axios.get('http://localhost:8080/news');
    if(!response.data) {
        throw new Error('Failed to fetch news');
    }
    const news = response.data;
    return (
        <div id="news">
            <h1>News</h1>
            <NewsList news={news} />
        </div>
    );
}