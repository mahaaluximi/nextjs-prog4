//route handler

export  function GET(request) {
    console.log('request',request)
   // return new Response.json({ message: 'Hello from the API route handler!' });
    return new Response('Hello from the API route handler!');
}