import { usePathname } from "next/navigation";
import Link from "next/link";
export default function NavLink({ path, children }) {
    const navPath = usePathname();
    return (
        <Link href={path} className={navPath.startsWith(path) ? 'active' : ''}>{children}</Link>
    );
}